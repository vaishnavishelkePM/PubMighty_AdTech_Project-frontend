'use client';

import axios from 'axios';
import { toast } from 'react-toastify';
import { useRef, useMemo, useState, useEffect, useCallback } from 'react';

import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Grid from '@mui/material/Grid';
import Table from '@mui/material/Table';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import Avatar from '@mui/material/Avatar';
import Tooltip from '@mui/material/Tooltip';
import Collapse from '@mui/material/Collapse';
import MenuItem from '@mui/material/MenuItem';
import TableRow from '@mui/material/TableRow';
import TextField from '@mui/material/TextField';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import CircularProgress from '@mui/material/CircularProgress';
import {
  Stack,
  Slide,
  Select,
  Divider,
  InputLabel,
  Pagination,
  FormControl,
  PaginationItem,
  TableContainer,
} from '@mui/material';

import { paths } from 'src/routes/paths';

import { getCookie } from 'src/utils/helper';
import { fDate, fTime } from 'src/utils/format-time';

import { CONFIG } from 'src/global-config';
import { DashboardContent } from 'src/layouts/dashboard';

import { Iconify } from 'src/components/iconify';
import { TableNoData } from 'src/components/table';
import { CustomBreadcrumbs } from 'src/components/custom-breadcrumbs';
import InventorySelector from 'src/components/selectors/inventory-selector';
import {
  TypeChip,
  TypeChips,
  StatusChip,
  AdsTxtChip,
  PartnerStatusChip,
} from 'src/components/chip/inventory-chip';

// NEW: separate dialogs
import AddInventoryFormDialog from './child/add-inventory-form-dialog';
import EditInventoryFormDialog from './child/edit-inventory-form-dialog';

// ----------------------------------------------------------------------

const TYPES = [
  { label: 'All', value: '' },
  { label: 'WEB', value: 'WEB' },
  { label: 'APP', value: 'APP' },
  { label: 'OTT/CTV', value: 'OTT_CTV' },
];

const STATUS = [
  { label: 'All', value: '' },
  { label: 'Inactive', value: 0 },
  { label: 'Active', value: 1 },
  { label: 'Blocked', value: 2 },
];

const PARTNER_STATUS = [
  { label: 'All', value: '' },
  { label: 'Unlinked', value: 0 },
  { label: 'Linked', value: 1 },
  { label: 'Paused', value: 2 },
];

const ADS_TXT_STATUS = [
  { label: 'All', value: '' },
  { label: 'Unknown', value: 0 },
  { label: 'OK', value: 1 },
  { label: 'Missing', value: 2 },
  { label: 'Mismatch', value: 3 },
];


function buildQuery(filters) {
  const qp = new URLSearchParams();

 
  ['id', 'publisherId', 'name', 'url', 'type'].forEach((k) => {
    const v = (filters[k] ?? '').toString().trim();
    if (v !== '') qp.append(k, v);
  });

  const numericMap = {
    status: filters.status,
    partnerStatus: filters.partnerStatus,
    adsTxtStatus: filters.adsTxtStatus,
  };
  Object.entries(numericMap).forEach(([k, v]) => {
    if (v !== '' && v !== null && v !== undefined) {
      qp.append(k, String(v));
    }
  });

  if (filters.sortBy) qp.append('sortBy', String(filters.sortBy));
  if (filters.sortDir) qp.append('sortDir', String(filters.sortDir));

  return qp.toString();
}


function Labeled({ label, children }) {
  return (
    <Stack direction="row" spacing={1.5} alignItems="baseline">
      <Typography variant="body2" color="text.secondary" sx={{ minWidth: 140 }}>
        {label}
      </Typography>
      <Typography variant="body2">{children}</Typography>
    </Stack>
  );
}

// ---------- Main component ----------

export default function InventoryView() {
  const token = useMemo(() => getCookie('session_key'), []);
  const headers = useMemo(
    () => ({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    }),
    [token]
  );

  const listUrlBase = `${CONFIG.apiUrl}/v1/admin/inventory`;

  const defaultFilters = {
    id: '', // NEW: inventory id filter
    publisherId: '',
    name: '',
    url: '',
    type: '',
    status: '',
    partnerStatus: '',
    adsTxtStatus: '',
    sortBy: 'updatedAt',
    sortDir: 'desc',
  };

  const [filters, setFilters] = useState(defaultFilters);
  const [showFilter, setShowFilter] = useState(false);
  const [rows, setRows] = useState([]);
  const [pagination, setPagination] = useState({ totalItems: 0, totalPages: 1, perPage: 20 });
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  const cacheRef = useRef({});

  // Dialogs
  const [viewOpen, setViewOpen] = useState(false);
  const [selected, setSelected] = useState(null);

  // NEW: separate Add / Edit dialogs
  const [openAdd, setOpenAdd] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [editId, setEditId] = useState(null);

  // Delete confirm
  const [deleteId, setDeleteId] = useState(null);
  const [deleting, setDeleting] = useState(false);

  // Avatar upload (publisher) inside View dialog
  const fileInputRef = useRef(null);
  const [isUploading, setIsUploading] = useState(false);

  const fetchInventories = useCallback(
    async (filter, page = 1, hardReload = false) => {
      try {
        setIsLoading(true);

        const qs = buildQuery(filter);
        const queryKey = `page=${page}&${qs}`;

        if (cacheRef.current[queryKey] && !hardReload) {
          const cached = cacheRef.current[queryKey];
          setRows(cached.rows);
          setPagination(cached.pagination);
          setIsLoading(false);
          return;
        }

        const url = `${listUrlBase}?page=${page}${qs ? `&${qs}` : ''}`;

        const res = await axios.get(url, {
          headers,
          validateStatus: () => true,
        });

        const data = res.data;
        if (data?.success) {
          const payload = data?.data || {};
          const _rows = Array.isArray(payload.rows) ? payload.rows : [];
          const pag = payload.pagination || {};
          const normPag = {
            totalItems: pag.totalItems ?? pag.total ?? _rows.length,
            totalPages: pag.totalPages ?? 1,
            perPage: pag.perPage ?? 20,
          };
          cacheRef.current[queryKey] = { rows: _rows, pagination: normPag };
          setRows(_rows);
          setPagination(normPag);
        } else {
          toast.error(data?.msg || data?.message || 'Failed to fetch inventories');
        }
      } catch (e) {
        console.error('fetchInventories error:', e);
        toast.error('Something went wrong while fetching inventories');
      } finally {
        setIsLoading(false);
      }
    },
    [headers, listUrlBase]
  );

  useEffect(() => {
    fetchInventories(defaultFilters, 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleFilterApply = () => {
    setCurrentPage(1);
    cacheRef.current = {};
    fetchInventories(filters, 1, true);
  };

  const handleFilterReset = () => {
    setFilters(defaultFilters);
    setCurrentPage(1);
    cacheRef.current = {};
    fetchInventories(defaultFilters, 1, true);
  };

  const handlePageChange = (_, p) => {
    setCurrentPage(p);
    fetchInventories(filters, p);
  };

  const handleCreate = () => {
    setEditId(null);
    setOpenAdd(true);
  };

  const handleEdit = (id) => {
    setEditId(id);
    setOpenEdit(true);
  };

  const handleDelete = (id) => setDeleteId(id);

  const confirmDelete = async () => {
    if (!deleteId) return;
    try {
      setDeleting(true);
      const res = await axios.delete(`${listUrlBase}/${deleteId}`, {
        headers,
        validateStatus: () => true,
      });
      if (res?.data?.success) {
        toast.success(res?.data?.msg || 'Inventory deleted');
        setDeleteId(null);
        fetchInventories(filters, currentPage, true);
      } else {
        toast.error(res?.data?.msg || res?.data?.message || 'Failed to delete inventory');
      }
    } catch (e) {
      console.error('delete error:', e);
      toast.error('Delete failed');
    } finally {
      setDeleting(false);
    }
  };

  const openView = (row) => {
    setSelected(row);
    setViewOpen(true);
  };

  // ---------- Avatar upload handlers (Publisher avatar in View dialog) ----------

  const handleClickUpload = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleChangeFile = async (event) => {
    const file = event.target.files?.[0];
    if (!file || !selected) return;

    const publisherId = selected.publisherId || selected.publisher?.id;
    if (!publisherId) {
      toast.error('No publisher ID found for this inventory');
      return;
    }

    try {
      setIsUploading(true);

      const formData = new FormData();
      formData.append('avatar', file);

      const url = `${CONFIG.apiUrl}/v1/admin/publishers/${publisherId}/avatar`;

      const resp = await axios.post(url, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'multipart/form-data',
        },
        validateStatus: () => true,
      });

      if (resp.data?.success) {
        const newAvatar = resp.data?.data?.avatar;

        if (!newAvatar) {
          toast.error('Avatar updated but no filename returned');
        } else {
          // Update selected dialog data (publisher object)
          setSelected((prev) =>
            prev
              ? {
                  ...prev,
                  publisher: {
                    ...(prev.publisher || {}),
                    avatar: newAvatar,
                  },
                }
              : prev
          );

          // Update avatar in the main table for all rows with same publisherId
          setRows((prevRows) =>
            prevRows.map((r) =>
              r.publisherId === publisherId
                ? {
                    ...r,
                    publisher: {
                      ...(r.publisher || {}),
                      avatar: newAvatar,
                    },
                  }
                : r
            )
          );

          toast.success(resp.data.message || resp.data.msg || 'Avatar updated');
        }
      } else {
        toast.error(resp.data?.message || resp.data?.msg || 'Failed to update avatar');
      }
    } catch (error) {
      console.error('Avatar upload failed', error);
      toast.error('Avatar upload failed');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // ----------------------------------------------------------------------

  return (
    <DashboardContent maxWidth="xl">
      {/* Breadcrumbs + actions */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <CustomBreadcrumbs
          heading="Inventory"
          links={[
            { name: 'Dashboard', href: paths.dashboard.root },
            { name: 'Inventory', href: paths.dashboard.inventory?.root || '#' },
          ]}
          sx={{ mb: 2 }}
        />
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mr: '10px', mb: '16px' }}>
          <Box sx={{ display: 'flex', width: '100%', justifyContent: 'flex-end', mb: 2 }}>
            <Box
              sx={{
                width: '100%',
                display: 'flex',
                justifyContent: 'flex-end',
                alignItems: 'center',
                gap: '8px',
              }}
            >
              <Button variant="contained" onClick={() => setShowFilter((prev) => !prev)}>
                <Iconify icon="stash:filter" sx={{ width: 20, mr: 1 }} />
                {showFilter ? 'Hide Filter' : 'Show Filter'}
              </Button>
              <Button variant="contained" onClick={handleCreate}>
                <Iconify icon="material-symbols:add" sx={{ width: 20, mr: 1 }} />
                Add
              </Button>
            </Box>
          </Box>
        </Box>
      </Box>

      {/* Filters panel */}
      <Collapse in={showFilter} timeout="auto" unmountOnExit>
        <Card sx={{ p: 2, mb: 2 }}>
          <Grid container spacing={2} alignItems="center">
            {/* Selector: inventory id or publisher username */}
            <Grid item xs={12} sm={6} md={3}>
              <InventorySelector
                label="Inventory / Publisher"
                placeholder="Type inventory ID or publisher username…"
                valueId={filters.id ? Number(filters.id) : undefined}
                onInventorySelect={(id) => {
                  // id is inventory id when user selects an option
                  const nextFilters = {
                    ...filters,
                    id: id || '',
                  };
                  setFilters(nextFilters);
                  setCurrentPage(1);
                  cacheRef.current = {};
                  fetchInventories(nextFilters, 1, true);
                }}
              />
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <TextField
                label="URL"
                value={filters.url}
                onChange={(e) =>
                  setFilters((prev) => ({
                    ...prev,
                    url: e.target.value,
                  }))
                }
                fullWidth
              />
            </Grid>

            {/* Type filter */}
            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <InputLabel>Type</InputLabel>
                <Select
                  value={filters.type}
                  label="Type"
                  onChange={(e) =>
                    setFilters((prev) => ({
                      ...prev,
                      type: e.target.value,
                    }))
                  }
                >
                  {TYPES.map((s) => (
                    <MenuItem key={String(s.value)} value={s.value}>
                      {s.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <InputLabel>Status</InputLabel>
                <Select
                  value={filters.status}
                  label="Status"
                  onChange={(e) =>
                    setFilters((prev) => ({
                      ...prev,
                      status: e.target.value,
                    }))
                  }
                >
                  {STATUS.map((s) => (
                    <MenuItem key={String(s.value)} value={s.value}>
                      {s.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <InputLabel>Partner Status</InputLabel>
                <Select
                  value={filters.partnerStatus}
                  label="Partner Status"
                  onChange={(e) =>
                    setFilters((prev) => ({
                      ...prev,
                      partnerStatus: e.target.value,
                    }))
                  }
                >
                  {PARTNER_STATUS.map((s) => (
                    <MenuItem key={String(s.value)} value={s.value}>
                      {s.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <InputLabel>ads.txt Status</InputLabel>
                <Select
                  value={filters.adsTxtStatus}
                  label="ads.txt Status"
                  onChange={(e) =>
                    setFilters((prev) => ({
                      ...prev,
                      adsTxtStatus: e.target.value,
                    }))
                  }
                >
                  {ADS_TXT_STATUS.map((s) => (
                    <MenuItem key={String(s.value)} value={s.value}>
                      {s.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <InputLabel>Sort By</InputLabel>
                <Select
                  value={filters.sortBy}
                  label="Sort By"
                  onChange={(e) =>
                    setFilters((prev) => ({
                      ...prev,
                      sortBy: e.target.value,
                    }))
                  }
                >
                  <MenuItem value="id">ID</MenuItem>
                  <MenuItem value="name">Name</MenuItem>
                  <MenuItem value="type">Type</MenuItem>
                  <MenuItem value="status">Status</MenuItem>
                  <MenuItem value="updatedAt">Updated At</MenuItem>
                  <MenuItem value="createdAt">Created At</MenuItem>
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>
              <FormControl fullWidth>
                <InputLabel>Order</InputLabel>
                <Select
                  value={filters.sortDir}
                  label="Order"
                  onChange={(e) =>
                    setFilters((prev) => ({
                      ...prev,
                      sortDir: e.target.value,
                    }))
                  }
                >
                  <MenuItem value="asc">Ascending</MenuItem>
                  <MenuItem value="desc">Descending</MenuItem>
                </Select>
              </FormControl>
            </Grid>

            <Grid
              item
              xs={12}
              md={12}
              sx={{
                gap: 1,
                display: 'flex',
                flexDirection: 'row',
                justifyContent: 'flex-end',
                alignItems: 'center',
              }}
            >
              <Button
                variant="outlined"
                onClick={handleFilterReset}
                disabled={isLoading}
                sx={{ height: 48 }}
              >
                Reset
              </Button>
              <Button
                variant="contained"
                onClick={handleFilterApply}
                disabled={isLoading}
                sx={{ height: 48 }}
              >
                Apply
              </Button>
            </Grid>
          </Grid>
        </Card>
      </Collapse>

      {/* KPI card */}
      <Card
        sx={{
          display: 'flex',
          mb: 2,
          mt: 2,
          p: 2,
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
          <Typography sx={{ fontSize: 14 }}>Total Inventories</Typography>
          <Typography sx={{ fontSize: 18, fontWeight: 700 }}>
            {pagination?.totalItems ?? 0}
          </Typography>
        </Box>
        <Box
          sx={{
            display: 'flex',
            p: 2,
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: '50%',
            bgcolor: '#8E33FF',
            color: '#fff',
          }}
        >
          <Iconify icon="mdi:database-outline" />
        </Box>
      </Card>

      {/* Table */}
      <Card>
        {isLoading ? (
          <Box sx={{ py: 6, display: 'flex', justifyContent: 'center' }}>
            <CircularProgress />
          </Box>
        ) : (
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>Publisher</TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>Inventory Name</TableCell>
                  <TableCell>Type</TableCell>
                  <TableCell>URL</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Partner</TableCell>
                  <TableCell>ads.txt</TableCell>
                  <TableCell>Updated</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {rows?.length ? (
                  rows.map((r) => {
                    const publisherName =
                      r.publisher?.username ||
                      r.publisher?.email ||
                      (r.publisherId ? `Publisher #${r.publisherId}` : '—');

                    const firstLetter = (publisherName || '?').charAt(0).toUpperCase();

                    return (
                      <TableRow key={r.id} hover>
                        <TableCell>{r.id}</TableCell>
                        <TableCell>
                          <Stack direction="row" alignItems="center" spacing={1.5}>
                            <Avatar
                              alt={publisherName}
                              src={
                                r.publisher?.avatar
                                  ? `${CONFIG.assetsUrl}/upload/publisher/${r.publisher.avatar}`
                                  : undefined
                              }
                              sx={{ width: 32, height: 32, fontSize: 14, fontWeight: 600 }}
                            >
                              {firstLetter}
                            </Avatar>

                            <Box>
                              <Typography variant="body2" fontWeight={500}>
                                {publisherName}
                              </Typography>

                              {r.publisher?.email && (
                                <Typography variant="caption" color="text.secondary">
                                  {r.publisher.email}
                                </Typography>
                              )}
                            </Box>
                          </Stack>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" fontWeight={600}>
                            {r.name || '—'}
                          </Typography>
                        </TableCell>

                        <TableCell>
                          <TypeChips value={r.type} />
                        </TableCell>

                        <TableCell>
                          <Box
                            component="a"
                            href={r.url || '#'}
                            target="_blank"
                            rel="noreferrer"
                            sx={{
                              color: 'primary.main',
                              textDecoration: r.url ? 'underline' : 'none',
                            }}
                            onClick={(e) => !r.url && e.preventDefault()}
                          >
                            {r.url || '—'}
                          </Box>
                        </TableCell>

                        <TableCell>
                          <StatusChip value={r.status} />
                        </TableCell>

                        <TableCell>
                          <PartnerStatusChip value={r.partnerStatus} />
                        </TableCell>

                        <TableCell>
                          <AdsTxtChip value={r.adsTxtStatus} />
                        </TableCell>

                        <TableCell>
                          {r.updatedAt ? (
                            <Stack spacing={0}>
                              <Typography variant="body2">{fDate(r.updatedAt)}</Typography>
                              <Typography variant="caption" color="text.secondary">
                                {fTime(r.updatedAt)}
                              </Typography>
                            </Stack>
                          ) : (
                            '—'
                          )}
                        </TableCell>

                        <TableCell align="right">
                          <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                            <Tooltip title="View details">
                              <IconButton size="small" onClick={() => openView(r)}>
                                <Iconify icon="solar:eye-bold" />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Edit">
                              <IconButton size="small" onClick={() => handleEdit(r.id)}>
                                <Iconify icon="solar:pen-bold" />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Delete">
                              <IconButton
                                size="small"
                                color="error"
                                onClick={() => handleDelete(r.id)}
                              >
                                <Iconify icon="solar:trash-bin-trash-bold" />
                              </IconButton>
                            </Tooltip>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={10}>
                      <TableNoData notFound />
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Card>

      {/* Pagination */}
      <Stack
        spacing={2}
        sx={{
          display: 'flex',
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
          m: 2,
        }}
      >
        <Pagination
          count={pagination?.totalPages || 1}
          page={currentPage}
          onChange={handlePageChange}
          renderItem={(item) => <PaginationItem {...item} />}
        />
      </Stack>

      {/* Add dialog */}
      <AddInventoryFormDialog
        open={openAdd}
        onClose={() => setOpenAdd(false)}
        onSuccess={() => {
          setOpenAdd(false);
          fetchInventories(filters, currentPage, true);
        }}
      />

      {/* Edit dialog */}
      <EditInventoryFormDialog
        open={openEdit}
        id={editId}
        onClose={() => setOpenEdit(false)}
        onSuccess={() => {
          setOpenEdit(false);
          fetchInventories(filters, currentPage, true);
        }}
      />

      {/* View Dialog */}
      <Dialog
        fullWidth
        maxWidth="md"
        open={viewOpen}
        onClose={() => setViewOpen(false)}
        TransitionComponent={Slide}
        TransitionProps={{ direction: 'up' }}
        PaperProps={{
          sx: (theme) => ({
            borderRadius: { xs: 2, sm: 3 },
            overflow: 'hidden',
            boxShadow: theme.shadows[24],
            border: `1px solid ${theme.palette.divider}`,
            bgcolor: 'background.paper',
          }),
        }}
      >
        <DialogTitle
          sx={{
            py: 2,
            px: 3,
            typography: 'h6',
            display: 'flex',
            alignItems: 'center',
            gap: 1.5,
          }}
        >
          <Iconify icon="mdi:calendar-plus" width={22} />
          Inventory #{selected?.id}
          <Box sx={{ flexGrow: 1 }} />
          {typeof selected?.status !== 'undefined' && <StatusChip value={selected?.status} />}
        </DialogTitle>

        <DialogContent
          dividers
          sx={{
            bgcolor: 'background.paper',
            maxHeight: 800,
            overflowY: 'auto',
            scrollBehavior: 'smooth',
            '&::-webkit-scrollbar': { width: 8 },
            '&::-webkit-scrollbar-thumb': {
              backgroundColor: (theme) => theme.palette.divider,
              borderRadius: 4,
            },
          }}
        >
          {!!selected && (
            <Stack spacing={2}>
              <Typography variant="subtitle2" color="text.secondary">
                Updated on {selected.updatedAt ? fDate(selected.updatedAt) : '—'}
              </Typography>

              <Divider flexItem />

              {/* Hidden file input for avatar upload */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                hidden
                onChange={handleChangeFile}
              />

              {/* Publisher profile */}
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="space-between"
                sx={{ mb: 3 }}
              >
                <Stack direction="row" alignItems="center" spacing={1.5}>
                  <Avatar
                    alt={
                      selected.publisher?.username ||
                      selected.publisher?.email ||
                      `Publisher #${selected.publisherId}`
                    }
                    src={
                      selected.publisher?.avatar
                        ? `${CONFIG.assetsUrl}/upload/publisher/${selected.publisher.avatar}`
                        : undefined
                    }
                    sx={{ width: 96, height: 96, fontSize: 20, fontWeight: 600 }}
                  >
                    {(selected.publisher?.username || selected.publisher?.email || `P`)
                      .charAt(0)
                      .toUpperCase()}
                  </Avatar>

                  <Box>
                    <Typography variant="body1" fontWeight={600}>
                      {selected.publisher?.username ||
                        selected.publisher?.email ||
                        (selected.publisherId ? `Publisher #${selected.publisherId}` : '—')}
                    </Typography>

                    {selected.publisher?.email && (
                      <Typography variant="caption" color="text.secondary">
                        {selected.publisher.email}
                      </Typography>
                    )}
                  </Box>
                </Stack>
              </Stack>

              <Grid container spacing={2}>
                {/* Identity */}
                <Grid item xs={12} sm={6}>
                  <Typography variant="overline" color="text.secondary">
                    Identity
                  </Typography>
                  <Stack spacing={1.25} sx={{ mt: 0.5 }}>
                    <Labeled label="ID">{selected.id}</Labeled>
                    <Labeled label="Name">{selected.name || '—'}</Labeled>
                    <Labeled label="Type">
                      <TypeChip value={selected.type} />
                    </Labeled>
                    <Labeled label="URL">
                      {selected.url ? (
                        <Box
                          component="a"
                          href={selected.url}
                          target="_blank"
                          rel="noreferrer"
                          sx={{ color: 'primary.main', textDecoration: 'underline' }}
                        >
                          {selected.url}
                        </Box>
                      ) : (
                        '—'
                      )}
                    </Labeled>
                  </Stack>
                </Grid>

                {/* Status */}
                <Grid item xs={12} sm={6}>
                  <Typography variant="overline" color="text.secondary">
                    Status
                  </Typography>
                  <Stack spacing={1.25} sx={{ mt: 0.5 }}>
                    <Labeled label="Inventory">
                      <StatusChip value={selected.status} />
                    </Labeled>
                    <Labeled label="Partner">
                      <PartnerStatusChip value={selected.partnerStatus} />
                    </Labeled>
                    <Labeled label="ads.txt">
                      <AdsTxtChip value={selected.adsTxtStatus} />
                    </Labeled>
                    <Labeled label="Publisher ID">{selected.publisherId ?? '—'}</Labeled>
                  </Stack>
                </Grid>

                {/* Timestamps */}
                <Grid item xs={12}>
                  <Typography variant="overline" color="text.secondary">
                    Timestamps
                  </Typography>
                  <Stack spacing={1.25} sx={{ mt: 0.5 }}>
                    <Labeled label="Created">
                      {selected.createdAt
                        ? `${fDate(selected.createdAt)} ${fTime(selected.createdAt)}`
                        : '—'}
                    </Labeled>
                    <Labeled label="Updated">
                      {selected.updatedAt
                        ? `${fDate(selected.updatedAt)} ${fTime(selected.updatedAt)}`
                        : '—'}
                    </Labeled>
                  </Stack>
                </Grid>
              </Grid>
            </Stack>
          )}
        </DialogContent>

        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setViewOpen(false)}>Close</Button>
          <Button
            variant="contained"
            startIcon={<Iconify icon="solar:pen-bold" />}
            onClick={() => {
              setViewOpen(false);
              if (selected?.id) {
                setEditId(selected.id);
                setOpenEdit(true);
              }
            }}
          >
            Edit
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={!!deleteId} onClose={() => setDeleteId(null)}>
        <DialogTitle>Delete Inventory</DialogTitle>
        <DialogContent>Are you sure you want to delete this inventory?</DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteId(null)} disabled={deleting}>
            Cancel
          </Button>
          <Button onClick={confirmDelete} color="error" variant="contained" disabled={deleting}>
            {deleting ? 'Deleting...' : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>
    </DashboardContent>
  );
}
